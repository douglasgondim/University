
#include <stdio.h>

int main(){
	int a,b;
	
	a=0;
	b=a++; // primeiro atribui depois incrementa
	
	printf("A saida é: % , %d\n",a,b);
	
	return 0;
}


#include <stdio.h>

int main(){
	int notas[5];
	printf("posicao de memoria %p\n", &notas[0]);
	printf("posicao de memoria %p\n", &notas[1]);
	printf("posicao de memoria %p\n", &notas[2]);
	printf("posicao de memoria %p\n", &notas[3]);
	printf("posicao de memoria %p\n", &notas[4]);
	return 0;
}

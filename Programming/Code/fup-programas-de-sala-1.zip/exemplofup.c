#include <stdio.h>

int main(){

	int A,B,SOMA;
	scanf("%d %d", &A,&B);
	SOMA = A+B;
	printf("SOMA = %d\n",SOMA);
	return 0;
}

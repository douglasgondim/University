#include <stdio.h>


int main(){
	int *p; //PONTEIRO DE INTEIRO
	float *f; //PONTEIRO DE FLOAT
	double *d; //PONTEIRO DE DOUBLE
	char *c; //PONTEIRO DE CHAR
	return 0;
}

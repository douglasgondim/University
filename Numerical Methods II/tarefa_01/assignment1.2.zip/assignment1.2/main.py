import numpy as np
import cv2
import matplotlib.pyplot as plt
import math

def dnorm(x, mu, sd):
    return 1 / (np.sqrt(2 * np.pi) * sd) * np.e ** (-np.power((x - mu) / sd, 2) / 2)


def gaussian_kernel(tam, sigma=1):
    kernel_1D = np.linspace(-(tam // 2), tam // 2, tam)
    for i in range(tam):
        kernel_1D[i] = dnorm(kernel_1D[i], 0, sigma)
    kernel_2D = np.outer(kernel_1D.T, kernel_1D.T)

    kernel_2D *= 1.0 / kernel_2D.max()

    return kernel_2D


def gaussian_blur(img, kernel_size):
    kernel = gaussian_kernel(kernel_size, sigma=math.sqrt(kernel_size))
    return convolucao(img, kernel, media=True)

def convolucao(img, kernel, media=False):
    if len(img.shape) == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    img_linha, img_coluna = img.shape
    kernel_linha, kernel_coluna = kernel.shape

    saida = np.zeros(img.shape)

    pad_height = int((kernel_linha - 1) / 2)
    pad_width = int((kernel_coluna - 1) / 2)

    padded_image = np.zeros((img_linha + (2 * pad_height), img_coluna + (2 * pad_width)))

    padded_image[pad_height:padded_image.shape[0] - pad_height, pad_width:padded_image.shape[1] - pad_width] = img

    for linha in range(img_linha):
        for coluna in range(img_coluna):
            saida[linha, coluna] = np.sum(kernel * padded_image[linha:linha + kernel_linha, coluna:coluna + kernel_coluna])
            if media:
                saida[linha, coluna] /= kernel.shape[0] * kernel.shape[1]

    return saida
    
def sobel_edge_detection(img, filtro):
    img_x = convolucao(img, filtro)

    img_y = convolucao(img, np.flip(filtro.T, axis=0))

    gradiente = np.sqrt(np.square(img_x) + np.square(img_y))

    gradiente *= 255.0 / gradiente.max()


    return gradiente


filtro = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]]) # vertical

img = cv2.imread('/Users/douglasgondim/Documents/college-2022.1/Numerical Methods II/assignment1.2/fruits.jpeg')

img = gaussian_blur(img, 9)
img = sobel_edge_detection(img, filtro)

plt.imshow(img, cmap='gray_r')
plt.title("Bordas Detectadas")
plt.show()